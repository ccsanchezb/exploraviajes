$(document).ready(function() {
    $('.form-group').tooltip();
});