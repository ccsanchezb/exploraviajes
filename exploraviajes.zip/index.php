<?php 
    $page = "home";
    include 'layout/header.php';
    include 'layout/topnavbar.php';
    include 'layout/carousel.php';  
    include 'layout/quote_form.php';
    include 'layout/destinos.php';      
    include 'layout/footer.php';
?>
