    </div>   
    <script src="http://localhost/exploraviajes/public/js/jquery-1.11.1.min.js"></script>
    <script src="http://localhost/exploraviajes/public/js/bootstrap.min.js"></script>
    <script src="http://localhost/exploraviajes/public/js/main.js"></script>
</body>
</html>