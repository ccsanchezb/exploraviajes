<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>
    <?php 
        switch ($page) {
            case 'value':
                # code...
                break;
            
            default:
                echo "Explora Viajes | Inicio";
                break;
        }
    ?>
    </title>
    <link rel="icon" type="image/png" href="http://localhost/exploraeventos/public/images/icons/favicon.png">
    <link rel="stylesheet" href="http://localhost/exploraviajes/public/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://localhost/exploraviajes/public/css/style.css">
</head>
<body>
    <div class="container">
        
    
